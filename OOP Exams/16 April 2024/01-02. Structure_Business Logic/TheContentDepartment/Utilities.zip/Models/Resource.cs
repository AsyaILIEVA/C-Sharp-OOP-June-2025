﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TheContentDepartment.Models.Contracts;

namespace TheContentDepartment.Models
{
    public abstract class Resource : IResource
    {
        public string Name => throw new NotImplementedException();

        public string Creator => throw new NotImplementedException();

        public int Priority => throw new NotImplementedException();

        public bool IsTested => throw new NotImplementedException();

        public bool IsApproved => throw new NotImplementedException();

        public void Approve()
        {
            throw new NotImplementedException();
        }

        public void Test()
        {
            throw new NotImplementedException();
        }
    }
}
