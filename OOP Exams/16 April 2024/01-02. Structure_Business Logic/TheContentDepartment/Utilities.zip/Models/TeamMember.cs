﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TheContentDepartment.Models.Contracts;

namespace TheContentDepartment.Models
{
    public abstract class TeamMember : ITeamMember
    {
        public string Name => throw new NotImplementedException();

        public string Path => throw new NotImplementedException();

        public IReadOnlyCollection<string> InProgress => throw new NotImplementedException();

        public void FinishTask(string resourceName)
        {
            throw new NotImplementedException();
        }

        public void WorkOnTask(string resourceName)
        {
            throw new NotImplementedException();
        }
    }
}
