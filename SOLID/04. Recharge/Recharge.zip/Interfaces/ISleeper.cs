﻿namespace P04.Recharge.Interfaces
{
    public interface ISleeper
    {
        void Sleep();
    }
}
