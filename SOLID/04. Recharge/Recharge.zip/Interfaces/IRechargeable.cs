﻿namespace P04.Recharge.Interfaces
{
    public interface IRechargeable
    {
        void Recharge();
    }
}
