﻿namespace P01.Stream_Progress
{
    public class Program
    {
        static void Main()
        {
            var progress = new StreamProgressInfo(new Music("", "", 10, 5));
        }
    }
}
