﻿using P02.Graphic_Editor.Interfaces;

namespace P02.Graphic_Editor
{
    public class Circle : IShape
    {
        public string Draw()
        {
            return "I'm Circle";
        }
    }
}
