﻿namespace P02.Graphic_Editor.Interfaces
{
    public interface IShape
    {
        string Draw();
    }
}
