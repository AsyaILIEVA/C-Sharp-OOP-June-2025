﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Raiding.Exceptions
{
    public class ExceptionMessages
    {
        public const string INVALID_HERO_EXCEPTION_MESSAGE = "Invalid hero!";
    }
}
